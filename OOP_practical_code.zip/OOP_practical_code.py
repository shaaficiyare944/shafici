class BankAccount:
    interest_rate = 0.05 
    def __init__(self, account_holder):
        self.account_holder = account_holder
        self.balance = 0
    def deposit(self, amount):
        self.balance += amount
    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Insufficient balance")
    def apply_interest(self):
        self.balance += self.balance * BankAccount.interest_rate
    def display_account_info(self):
        print(f"Account Holder: {self.account_holder}")
        print(f"Balance: {self.balance}")

class Product:
    def __init__(self, product_name, price, quantity_in_stock):
        self.product_name = product_name
        self.price = price
        self.quantity_in_stock = quantity_in_stock
    def display_product_info(self):
        print(f"Product: {self.product_name}, Price: {self.price}, In Stock: {self.quantity_in_stock}")

class ShoppingCart:
    total_carts = 0
    
    def __init__(self):
        self.items = [] 
        ShoppingCart.total_carts += 1
    def add_to_cart(self, product, quantity):
        if product.quantity_in_stock >= quantity:
            self.items.append((product, quantity))
            product.quantity_in_stock -= quantity
        else:
            print(f"Not enough stock for {product.product_name}")
    def remove_from_cart(self, product):
        for item in self.items:
            if item[0] == product:
                self.items.remove(item)
                product.quantity_in_stock += item[1]
                break
    def display_cart(self):
        print("Items in cart:")
        for item in self.items:
            product, quantity = item
            print(f"{product.product_name}: {quantity}")
    def calculate_total(self):
        total = sum(item[0].price * item[1] for item in self.items)
        return total

# Example Usage
product1 = Product("Laptop", 1000, 5)
product2 = Product("Phone", 500, 10)
product3 = Product("Headphones", 100, 20)

cart1 = ShoppingCart()
cart1.add_to_cart(product1, 1)
cart1.add_to_cart(product2, 2)

cart2 = ShoppingCart()
cart2.add_to_cart(product3, 3)

cart1.display_cart()
cart2.display_cart()

print(f"Total for Cart 1: ${cart1.calculate_total()}")
print(f"Total for Cart 2: ${cart2.calculate_total()}")